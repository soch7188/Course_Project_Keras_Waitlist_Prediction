README File for Phase 2
1. Group Information
    Group # 29
    1. Hu, Yao-Chieh (20216239)
    2. Kim, Ziwon    (20216497)

2. File List & Description
    - insertions.js
        Insertion script for submission. Inserts multiple courses with sections into collection. Should have started up mongodb before insertion.
    - query.js
        Query script for submission. Supports Query by Keyword, and Query by Waitlist Size. Should have inserted data with insertion.js before querying.
    - JS_queries_for_dev_and_testing.zip
        MongoDB script files for development and testing.

3. Known bugs of your system
    None