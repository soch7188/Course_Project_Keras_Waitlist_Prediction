def run():
    # Welcome message
    print("4. Waiting List Size Prediction !\n")

    cc = input("Input Course Code >>  ") # course code
    ln = input("Input Lecture Number >>  ") # course code
    ts = input("Input Time Slot >>  ") # course code

    # Main execution
    print("Executing")
    print("N1, N2, N3, N4, N5")
    print("Warning: This is a stub.\n")

    return