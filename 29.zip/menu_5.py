def run():
    # Welcome message
    print("5. Waiting List Size Training !\n")

    # Main execution
    print("Executing Training Process ... ")

    print("Waiting list size training is successful")
    print("Warning: This is a stub.\n")

    return